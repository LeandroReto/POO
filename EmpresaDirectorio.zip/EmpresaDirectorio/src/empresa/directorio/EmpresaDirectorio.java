/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empresa.directorio;

import vista.VistaGeneral;

/**
 *
 * @author jaslyn
 */
public class EmpresaDirectorio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        VistaGeneral vistaGeneral=new VistaGeneral();
        vistaGeneral.menu();
        
                
    }
    
}
